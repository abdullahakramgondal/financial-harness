# FH-3: MCP and PTC Integration

Portfolio Manager cloud harness ka FH-3 hissa: agent **MCP** ke zariye tools se connect hota hai
aur **PTC (Programmatic Tool Calling)** se code likh kar tools chalata hai. Raw data context mein
nahi jata, sirf chhota summary jata hai.

## 7 Steps -> Files

| Step | Kaam | File |
|---|---|---|
| 1 | Project structure | poora folder, `harness/config.py`, `harness/logger.py` |
| 2 | Market-data MCP server | `harness/mcp_servers/market_data_server.py`, `harness/data_provider.py` |
| 3 | Portfolio MCP server | `harness/mcp_servers/portfolio_server.py`, `harness/portfolio_logic.py`, `data/holdings.json` |
| 4 | MCP client (discover, call, timeout, logging) | `harness/mcp_client.py` |
| 5 | PTC bridge (allow-list, approval hook, call limit) | `harness/ptc_bridge.py`, `harness/ptc_sandbox.py` |
| 6 | Context integration | `harness/context_adapter.py` |
| 7 | Tests, demo, Jira | `tests/`, `run_demo.py`, `docs/FH-3_jira_update.md` |

## VS Code mein chalane ka tareeqa

Python 3.10+ chahiye.

```bash
# 1) folder VS Code mein kholein, terminal kholein
python -m venv .venv
# Windows:  .venv\Scripts\activate        Mac/Linux:  source .venv/bin/activate
pip install -r requirements.txt

# 2) config
cp .env.example .env        # Windows: copy .env.example .env
# default DATA_PROVIDER=mock hai, key ki zaroorat nahi

# 3) pehle bina MCP ke chala kar logic check karein
python run_demo.py --local

# 4) ab asli MCP servers ke saath (asli deliverable)
python run_demo.py

# 5) tests
python -m unittest discover -s tests -t . -v
```

VS Code mein `Run and Debug` panel se bhi chal sakta hai (`.vscode/launch.json` mein 3 configs hain).

Demo ke baad dekhein:
- `outputs/demo_result.json`: poora result
- `logs/tool_calls.jsonl`: har tool call ka log (FH-7 ke liye)
- `artifacts/`: bade outputs jo context ki jagah file mein gaye

> **Note:** `requirements.txt` mein `mcp<2` lazmi hai. mcp 2.x mein `FastMCP` ka naam `MCPServer` ho gaya hai, aur ye code 1.x ke liye likha hai. Verified: mcp 1.30.0 par 28/28 tests pass.

## Live data kaise lagayein

`.env` mein:
```
DATA_PROVIDER=polygon
POLYGON_API_KEY=...
```
- Polygon free tier delayed/end-of-day data deti hai aur rate limit ~5 requests/min hai. Isliye 5 min ka cache hai.
- `FALLBACK_TO_MOCK=true` ho to fail hone par mock par chala jata hai. Har result mein `"source"` hota hai, aur demo output ki pehli line mein bhi dikhta hai. **Demo mein "live" tab hi kahein jab source `polygon` ho.**
- `finnhub` sirf quote deta hai (free tier mein history nahi).
- Asli Nasdaq live feed ke liye license chahiye; development ke liye delayed tier theek hai.

## Agent ko Claude se code likhwana (optional)

```bash
pip install anthropic
# .env mein ANTHROPIC_API_KEY daalein
python run_demo.py --llm
```
Default demo scripted agent use karta hai, jo isi PTC pipeline se guzarta hai.

## Architecture

```
run_demo.py
   |
   +-- SyncMCPClient --stdio--> market_data_server.py  (get_quote, get_history, list_symbols)
   |                      \---> portfolio_server.py    (get_positions, calc_exposure, calc_risk)
   |
   +-- PTCBridge (127.0.0.1, token, allow-list, limit)
   |        ^  HTTP
   |        |
   +-- ptc_sandbox.run_code(agent code)   `import tools; tools.get_history("AAPL")`
   |
   +-- ContextAdapter  -> sirf chhota summary context mein, bada output artifacts/ mein
```

## Dusri tickets ke saath interface

- **FH-2 (Abdullah, context):** `ContextAdapter.process(label, payload)` return karta hai
  `{label, truncated, chars, approx_tokens, content | summary + artifact_path}`.
- **FH-5 (Aima, sandbox):** `ptc_sandbox.run_code(code, bridge)` ki jagah unka Docker sandbox lag sakta hai.
  Unhein sirf `bridge.url` aur `bridge.token` env vars ke taur par chahiye, aur `bridge.stub_source()` ko `tools.py`
  ki tarah rakhna hai. Agar sandbox container mein ho to bridge ko `0.0.0.0`/host address par bind karna padega
  (`ptc_bridge.py` mein `127.0.0.1` badlein) aur token ki hifazat barqarar rakhein.
- **FH-4 (Faizan, guardrails):** `RESTRICTED_TOOLS` (`place_order`, ...) default block hain.
  `PTCBridge(client, approval_hook=fn)` mein `fn(tool, args) -> bool` dein.

## Mahdood cheezein (sach)

- `ptc_sandbox.py` sirf placeholder hai: alag process, timeout, saaf env, lekin **asli isolation nahi**. Untrusted/LLM code ke liye FH-5 ka sandbox lazmi hai.
- `calc_risk` hypothetical hai: maujooda shares ko pichle N din par constant maan kar nikalta hai.
- Mock data sirf demo ke liye hai, isse koi asli faisla na karein.
