# FH-3 MCP and PTC Integration: Jira update (copy/paste)

## Summary
Harness ko MCP (2 servers: market-data, portfolio) se jorra aur PTC bridge banaya jisse agent ka
code tools ko functions ki tarah call karta hai. Raw tool data context mein nahi jata.

## Sub-tasks (status: Done jab check ho jayein)
- [ ] FH-3.1 Project structure + config + logging
- [ ] FH-3.2 Market-data MCP server (get_quote, get_history, list_symbols)
- [ ] FH-3.3 Portfolio MCP server (get_positions, calc_exposure, calc_risk)
- [ ] FH-3.4 MCP client (discovery, timeout, error handling, tool-call log)
- [ ] FH-3.5 PTC bridge (allow-list, restricted tools, call limit, token)
- [ ] FH-3.6 Context adapter (bada output -> file + summary)
- [ ] FH-3.7 Tests + demo + handover

## Acceptance criteria
- [ ] Agent sawal ka jawab code likh kar deta hai: "top 5 tech stocks ka 90 din ka trend vs QQQ"
- [ ] `python run_demo.py` MCP mode mein chalta hai (screenshot lagayein)
- [ ] Raw data context mein nahi gaya (demo stats mein "Context bachat" dikhayein)
- [ ] `place_order` jaise tools block hote hain (test_ptc_bridge)
- [ ] Har tool call `logs/tool_calls.jsonl` mein log hoti hai
- [ ] `python -m unittest discover -s tests -t .` pass (MCP tests ke saath, `mcp` install karke)

## Handover
- FH-2 (Abdullah): ContextAdapter.process() ka output format
- FH-5 (Aima): run_code(code, bridge) interface, bridge.url/token, stub_source()
- FH-4 (Faizan): RESTRICTED_TOOLS + approval_hook(tool, args) -> bool
- FH-7 (Emaan): logs/tool_calls.jsonl ka format (ts, tool, args, status, duration_ms, source, error)

## Known limitations
- Sandbox placeholder hai (FH-5 asli isolation dega)
- Data provider: mock default; live ke liye Polygon key (delayed)
