"""Demo agent code: "Top 5 tech stocks ka 90 din ka trend QQQ ke muqable mein".

Ye wohi code hai jo LLM agent likhta (PTC). Ye sandbox ke andar `import tools` karta hai,
raw data (6 x 90 bars) python ke andar rehta hai, aur sirf chhota summary print hota hai.
"""

DEMO_QUESTION = "Mere top 5 tech stocks ka 90 din ka trend QQQ ke muqable mein dikhao."

DEFAULT_AGENT_CODE = '''
import tools

TECH = ["AAPL", "MSFT", "NVDA", "AMZN", "GOOGL"]
DAYS = 90


def pct_return(bars):
    return (bars[-1]["close"] / bars[0]["close"] - 1) * 100


bench = tools.get_history("QQQ", days=DAYS)
b_ret = pct_return(bench["bars"])
sources = {bench["source"]}

rows = []
for sym in TECH:
    h = tools.get_history(sym, days=DAYS)
    sources.add(h["source"])
    r = pct_return(h["bars"])
    rows.append((sym, r, r - b_ret, h["bars"][-1]["close"]))
rows.sort(key=lambda x: x[2], reverse=True)

print("Data source:", ", ".join(sorted(sources)))
print(f"QQQ {DAYS}-trading-day return: {b_ret:+.2f}%")
print(f"{'Symbol':<8}{'Return%':>10}{'vs QQQ':>10}{'Last':>10}")
for sym, r, rel, last in rows:
    print(f"{sym:<8}{r:>+10.2f}{rel:>+10.2f}{last:>10.2f}")

exp = tools.calc_exposure()
risk = tools.calc_risk(days=DAYS)
top = exp["by_sector"][0]
print(f"Top sector: {top['sector']} ({top['weight_pct']}% of portfolio)")
print(
    f"Portfolio beta vs QQQ: {risk['beta_vs_qqq']} | "
    f"annual vol: {risk['annual_volatility_pct']}% | "
    f"max drawdown: {risk['max_drawdown_pct']}% | 1d VaR95: {risk['var_95_1d_pct']}%"
)
'''
