"""Central config. Sab settings .env ya environment variables se aati hain."""
from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

try:
    from dotenv import load_dotenv

    load_dotenv(ROOT / ".env")
except ImportError:  # dotenv optional hai
    pass


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except ValueError:
        return default


DATA_PROVIDER = os.getenv("DATA_PROVIDER", "mock").strip().lower()
POLYGON_API_KEY = os.getenv("POLYGON_API_KEY", "")
FINNHUB_API_KEY = os.getenv("FINNHUB_API_KEY", "")
FALLBACK_TO_MOCK = os.getenv("FALLBACK_TO_MOCK", "true").strip().lower() in ("1", "true", "yes")

ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5-5")

LOG_DIR = ROOT / "logs"
ARTIFACT_DIR = ROOT / "artifacts"
OUTPUT_DIR = ROOT / "outputs"
HOLDINGS_FILE = ROOT / "data" / "holdings.json"

MAX_CONTEXT_CHARS = _int("MAX_CONTEXT_CHARS", 2000)
SANDBOX_TIMEOUT = _int("SANDBOX_TIMEOUT", 60)
MAX_BRIDGE_CALLS = _int("MAX_BRIDGE_CALLS", 200)
MCP_CALL_TIMEOUT = _int("MCP_CALL_TIMEOUT", 30)

for _d in (LOG_DIR, ARTIFACT_DIR, OUTPUT_DIR):
    _d.mkdir(parents=True, exist_ok=True)
