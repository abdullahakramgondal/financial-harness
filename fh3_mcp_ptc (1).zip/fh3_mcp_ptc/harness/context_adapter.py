"""Context integration (Step 6) - FH-2 (context management) ke saath interface.

Rule: chhota result seedha context mein; bada result file mein save + context mein sirf
summary aur artifact_path. Agent baad mein read_artifact() se zaroorat ka hissa parh sakta hai.

FH-2 ke liye contract:
    ContextAdapter().process(label, payload) -> dict
      {label, truncated, chars, approx_tokens, content | (summary, artifact_path)}
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any

from . import config


class ContextAdapter:
    def __init__(self, max_chars: int | None = None, artifact_dir: Path | None = None, preview_chars: int = 300):
        self.max_chars = max_chars or config.MAX_CONTEXT_CHARS
        self.artifact_dir = Path(artifact_dir or config.ARTIFACT_DIR)
        self.preview_chars = preview_chars
        self.artifact_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def estimate_tokens(text: str) -> int:
        return max(1, len(text) // 4)  # mota andaza

    def process(self, label: str, payload: Any) -> dict:
        text = payload if isinstance(payload, str) else json.dumps(payload, default=str)
        if len(text) <= self.max_chars:
            return {
                "label": label,
                "truncated": False,
                "chars": len(text),
                "approx_tokens": self.estimate_tokens(text),
                "content": text,
            }
        path = self._save(label, text, is_json=not isinstance(payload, str))
        summary = self._summarize(payload, text)
        return {
            "label": label,
            "truncated": True,
            "chars": len(text),
            "approx_tokens": self.estimate_tokens(summary),
            "summary": summary,
            "artifact_path": str(path),
        }

    def read_artifact(self, path: str, offset: int = 0, limit: int = 2000) -> str:
        p = Path(path).resolve()
        if self.artifact_dir.resolve() not in p.parents:
            raise PermissionError("Path artifact directory ke bahar hai")
        with open(p, encoding="utf-8") as f:
            f.seek(offset)
            return f.read(limit)

    # ------------------------------------------------------------ internals
    def _save(self, label: str, text: str, is_json: bool) -> Path:
        safe = re.sub(r"[^A-Za-z0-9_.-]", "_", label)[:40] or "artifact"
        digest = hashlib.sha1(text.encode()).hexdigest()[:8]
        path = self.artifact_dir / f"{safe}_{digest}.{'json' if is_json else 'txt'}"
        path.write_text(text, encoding="utf-8")
        return path

    def _summarize(self, payload: Any, text: str) -> str:
        def short(v: Any, n: int = 120) -> str:
            s = json.dumps(v, default=str)
            return s if len(s) <= n else s[:n] + "..."

        if isinstance(payload, list):
            first = f"; first item: {short(payload[0])}" if payload else ""
            return f"list with {len(payload)} items{first}"
        if isinstance(payload, dict):
            parts = []
            for k, v in payload.items():
                if isinstance(v, list):
                    parts.append(f"{k}: list[{len(v)}]")
                elif isinstance(v, dict):
                    parts.append(f"{k}: dict({len(v)} keys)")
                else:
                    parts.append(f"{k}: {short(v, 40)}")
            return "dict -> " + ", ".join(parts)
        return text[: self.preview_chars] + f"... [{len(text)} chars total]"
