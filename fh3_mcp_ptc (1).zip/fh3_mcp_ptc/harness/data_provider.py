"""Market data layer (Step 2).

Providers:
  mock     - deterministic fake data (default; demo kabhi nahi rukta)
  polygon  - daily bars (free tier delayed/EOD hoti hai, rate limit ~5 req/min)
  finnhub  - sirf quote (free tier mein historical candles nahi hoti)

Agar live provider fail ho aur FALLBACK_TO_MOCK=true ho, to mock par girta hai
aur result mein "source": "mock" aata hai, taake pata rahe data asli hai ya nahi.
"""
from __future__ import annotations

import hashlib
import json
import random
import re
import time
import urllib.parse
import urllib.request
from datetime import date, datetime, timedelta, timezone
from typing import Any

from . import config
from .logger import get_logger

log = get_logger(__name__)

UNIVERSE: dict[str, str] = {
    "AAPL": "Technology",
    "MSFT": "Technology",
    "NVDA": "Technology",
    "AVGO": "Technology",
    "AMD": "Technology",
    "AMZN": "Consumer Discretionary",
    "TSLA": "Consumer Discretionary",
    "GOOGL": "Communication Services",
    "META": "Communication Services",
    "NFLX": "Communication Services",
    "QQQ": "ETF (Nasdaq-100)",
}

_SYMBOL_RE = re.compile(r"^[A-Z][A-Z.\-]{0,5}$")
_N_BARS = 504  # mock series length (~2 saal)
_CACHE_TTL = 300
_cache: dict[tuple, tuple[float, dict]] = {}


def _clean_symbol(symbol: str) -> str:
    s = str(symbol).strip().upper()
    if not _SYMBOL_RE.match(s):
        raise ValueError(f"Invalid symbol: {symbol!r}")
    return s


def _fallback_or_raise(exc: Exception) -> None:
    if not config.FALLBACK_TO_MOCK:
        raise exc
    log.warning("Live provider failed (%s). Falling back to mock data.", exc)


# ----------------------------------------------------------------- mock data
def _trading_dates(n: int) -> list[date]:
    d, out = date.today(), []
    while len(out) < n:
        if d.weekday() < 5:
            out.append(d)
        d -= timedelta(days=1)
    return out[::-1]


def _market_returns() -> list[float]:
    rng = random.Random(20260101)
    return [rng.gauss(0.0003, 0.011) for _ in range(_N_BARS)]


def _mock_history(symbol: str, days: int) -> list[dict]:
    seed = int(hashlib.md5(symbol.encode()).hexdigest()[:8], 16)
    rng = random.Random(seed)
    is_idx = symbol == "QQQ"
    beta = 1.0 if is_idx else rng.uniform(0.8, 1.7)
    idio = 0.0 if is_idx else rng.uniform(0.006, 0.014)
    alpha = 0.0 if is_idx else rng.uniform(-0.0003, 0.0004)
    price = 300.0 if is_idx else 40 + rng.random() * 400

    mkt, dates, bars = _market_returns(), _trading_dates(_N_BARS), []
    for i in range(_N_BARS):
        r = alpha + beta * mkt[i] + rng.gauss(0, idio)
        o, c = price, price * (1 + r)
        hi = max(o, c) * (1 + abs(rng.gauss(0, 0.004)))
        lo = min(o, c) * (1 - abs(rng.gauss(0, 0.004)))
        bars.append(
            {
                "date": dates[i].isoformat(),
                "open": round(o, 2),
                "high": round(hi, 2),
                "low": round(lo, 2),
                "close": round(c, 2),
                "volume": int(rng.uniform(1e6, 5e7)),
            }
        )
        price = c
    return bars[-days:]


# ------------------------------------------------------------- live providers
def _http_json(url: str) -> Any:
    req = urllib.request.Request(url, headers={"User-Agent": "fh3-harness/1.0"})
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.load(resp)


def _polygon_history(symbol: str, days: int) -> list[dict]:
    if not config.POLYGON_API_KEY:
        raise RuntimeError("POLYGON_API_KEY not set")
    end = date.today()
    start = end - timedelta(days=int(days * 1.7) + 10)
    qs = urllib.parse.urlencode(
        {"adjusted": "true", "sort": "asc", "limit": 5000, "apiKey": config.POLYGON_API_KEY}
    )
    url = f"https://api.polygon.io/v2/aggs/ticker/{symbol}/range/1/day/{start}/{end}?{qs}"
    results = (_http_json(url) or {}).get("results") or []
    if not results:
        raise RuntimeError(f"No bars returned for {symbol}")
    bars = [
        {
            "date": datetime.fromtimestamp(r["t"] / 1000, tz=timezone.utc).strftime("%Y-%m-%d"),
            "open": r["o"],
            "high": r["h"],
            "low": r["l"],
            "close": r["c"],
            "volume": int(r["v"]),
        }
        for r in results
    ]
    return bars[-days:]


def _finnhub_quote(symbol: str) -> dict:
    if not config.FINNHUB_API_KEY:
        raise RuntimeError("FINNHUB_API_KEY not set")
    qs = urllib.parse.urlencode({"symbol": symbol, "token": config.FINNHUB_API_KEY})
    q = _http_json(f"https://finnhub.io/api/v1/quote?{qs}")
    if not q or not q.get("c"):
        raise RuntimeError(f"Empty quote for {symbol}")
    return {
        "symbol": symbol,
        "price": q["c"],
        "prev_close": q["pc"],
        "change": q["d"],
        "change_pct": q["dp"],
        "as_of": datetime.fromtimestamp(q["t"], tz=timezone.utc).isoformat(),
        "source": "finnhub",
    }


# ------------------------------------------------------------------ public API
def list_symbols() -> dict:
    """List the symbols available in this harness with their sectors."""
    return {"symbols": [{"symbol": s, "sector": sec} for s, sec in UNIVERSE.items()]}


def get_history(symbol: str, days: int = 90) -> dict:
    """Daily OHLCV bars for the last N trading days (5-500). Oldest first."""
    symbol = _clean_symbol(symbol)
    days = max(5, min(int(days), 500))
    provider = config.DATA_PROVIDER
    source = "mock"
    bars: list[dict] | None = None

    if provider in ("polygon", "finnhub"):
        key = (provider, symbol, days)
        hit = _cache.get(key)
        if hit and time.time() - hit[0] < _CACHE_TTL:
            return hit[1]
        try:
            if provider == "polygon":
                bars, source = _polygon_history(symbol, days), "polygon"
            else:
                raise RuntimeError("finnhub free tier has no historical candles")
        except Exception as exc:  # noqa: BLE001
            _fallback_or_raise(exc)

    if bars is None:
        bars, source = _mock_history(symbol, days), "mock"

    result = {"symbol": symbol, "days": days, "count": len(bars), "source": source, "bars": bars}
    if source != "mock":
        _cache[(provider, symbol, days)] = (time.time(), result)
    return result


def get_quote(symbol: str) -> dict:
    """Latest quote (price, previous close, change) for a Nasdaq-listed symbol."""
    symbol = _clean_symbol(symbol)
    if config.DATA_PROVIDER == "finnhub":
        try:
            return _finnhub_quote(symbol)
        except Exception as exc:  # noqa: BLE001
            _fallback_or_raise(exc)

    h = get_history(symbol, 5)
    last, prev = h["bars"][-1], h["bars"][-2]
    change = last["close"] - prev["close"]
    return {
        "symbol": symbol,
        "price": last["close"],
        "prev_close": prev["close"],
        "change": round(change, 2),
        "change_pct": round(change / prev["close"] * 100, 2),
        "as_of": last["date"],
        "source": h["source"],
    }
