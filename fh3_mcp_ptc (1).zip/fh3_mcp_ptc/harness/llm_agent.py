"""OPTIONAL: agent ka code Claude se generate karwana (run_demo.py --llm).

Ye step demo ke liye zaroori nahi; default scripted agent (agent_demo.py) kaafi hai.
Zaroorat: pip install anthropic, aur .env mein ANTHROPIC_API_KEY.
Model ka naam .env ke ANTHROPIC_MODEL se aata hai. Docs: https://docs.claude.com
"""
from __future__ import annotations

import re

from . import config

SYSTEM = """You write a short Python 3 script that answers the user's portfolio question.
Rules:
- The script does `import tools` and calls ONLY the functions listed below, using plain Python.
- Do all loops/aggregation in code. NEVER print raw bars or large lists.
- Print only a compact summary (max ~20 lines).
- Standard library only. No network, no file writes.
Return ONLY the code, no explanations."""


def generate_code(question: str, tool_docs: list[str]) -> str:
    import anthropic  # lazy import

    client = anthropic.Anthropic()
    msg = client.messages.create(
        model=config.ANTHROPIC_MODEL,
        max_tokens=1500,
        system=SYSTEM,
        messages=[{"role": "user", "content": "Available functions:\n" + "\n".join(tool_docs) + f"\n\nQuestion: {question}"}],
    )
    text = "".join(b.text for b in msg.content if getattr(b, "type", "") == "text")
    m = re.search(r"```(?:python)?\n(.*?)```", text, re.S)
    return (m.group(1) if m else text).strip()
