"""LocalClient: SyncMCPClient jaisa interface, lekin MCP ke baghair functions seedha call karta hai.

Kab kaam aata hai:
  * `python run_demo.py --local`  -> agar MCP SDK/stdio mein masla ho to bhi demo chal jaye
  * unit tests (tezi se chalte hain)
Asli deliverable MCP path hai; ye sirf fallback / test helper hai.
"""
from __future__ import annotations

import inspect
import json
import time
from typing import Any, Callable

from . import data_provider as dp, portfolio_logic as pl
from .logger import log_tool_call

_JSON_TYPES = {"int": "integer", "float": "number", "str": "string", "bool": "boolean"}


def spec_from_function(fn: Callable) -> dict:
    sig = inspect.signature(fn)
    props, required = {}, []
    for pname, p in sig.parameters.items():
        ann = p.annotation
        tname = ann if isinstance(ann, str) else getattr(ann, "__name__", "str")
        prop: dict[str, Any] = {"type": _JSON_TYPES.get(tname, "string")}
        if p.default is inspect.Parameter.empty:
            required.append(pname)
        else:
            prop["default"] = p.default
        props[pname] = prop
    return {
        "name": fn.__name__,
        "description": (inspect.getdoc(fn) or "").split("\n\n")[0].replace("\n", " "),
        "inputSchema": {"type": "object", "properties": props, "required": required},
    }


class LocalClient:
    def __init__(self) -> None:
        fns = [dp.get_quote, dp.get_history, dp.list_symbols, pl.get_positions, pl.calc_exposure, pl.calc_risk]
        self._fns = {f.__name__: f for f in fns}
        self.tool_specs = {n: spec_from_function(f) for n, f in self._fns.items()}

    def start(self, timeout: float = 0) -> None:
        pass

    def stop(self) -> None:
        pass

    def call(self, name: str, args: dict | None = None, timeout: int | None = None) -> Any:
        args = args or {}
        if name not in self._fns:
            raise KeyError(f"Unknown tool: {name}")
        start = time.perf_counter()
        try:
            result = self._fns[name](**args)
        except Exception as exc:  # noqa: BLE001
            log_tool_call(name, args, "error", (time.perf_counter() - start) * 1000, "local", str(exc))
            raise
        log_tool_call(
            name, args, "ok", (time.perf_counter() - start) * 1000, "local",
            result_chars=len(json.dumps(result, default=str)),
        )
        return result
