"""Logging. Har tool call logs/tool_calls.jsonl mein jati hai (FH-7 monitoring ke liye).

NOTE: MCP stdio servers mein stdout protocol ke liye reserved hai, isliye
console logging hamesha stderr par hoti hai.
"""
from __future__ import annotations

import json
import logging
import os
import sys
import threading
from datetime import datetime, timezone
from typing import Any

from . import config

_lock = threading.Lock()
TOOL_LOG = config.LOG_DIR / "tool_calls.jsonl"


def get_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stderr)
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
        logger.addHandler(handler)
        logger.setLevel(os.getenv("LOG_LEVEL", "INFO"))
        logger.propagate = False
    return logger


def log_tool_call(
    tool: str,
    args: dict[str, Any] | None,
    status: str,
    duration_ms: float,
    source: str = "harness",
    error: str | None = None,
    result_chars: int | None = None,
) -> None:
    """status: ok | error | denied"""
    record = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "tool": tool,
        "args": args or {},
        "status": status,
        "duration_ms": round(duration_ms, 1),
        "source": source,
        "result_chars": result_chars,
        "error": error,
    }
    with _lock:
        with open(TOOL_LOG, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, default=str) + "\n")
