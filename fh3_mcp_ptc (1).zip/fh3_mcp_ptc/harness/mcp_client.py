"""MCP client (Step 4).

Harness is client ke zariye MCP servers se connect hota hai (stdio transport):
  connect -> list_tools (discovery) -> call_tool (timeout + error handling + logging)

Do classes:
  MCPManager      - async, asli kaam yahan hota hai
  SyncMCPClient   - background thread mein MCPManager chalata hai aur sync call() deta hai
                    (PTC bridge ka HTTP thread isi ko use karta hai)
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import threading
import time
from contextlib import AsyncExitStack
from typing import Any

from . import config
from .logger import get_logger, log_tool_call

log = get_logger(__name__)

# server name -> python args (har server alag subprocess hai)
DEFAULT_SERVERS: dict[str, list[str]] = {
    "market": ["-m", "harness.mcp_servers.market_data_server"],
    "portfolio": ["-m", "harness.mcp_servers.portfolio_server"],
}


class ToolError(Exception):
    """Tool ne error return kiya ya call fail hui."""


def parse_tool_result(result: Any) -> Any:
    """MCP CallToolResult ko plain Python object mein badalta hai."""
    texts = [c.text for c in (result.content or []) if getattr(c, "type", "") == "text"]
    if getattr(result, "isError", False):
        raise ToolError(" ".join(texts) or "tool returned an error")

    structured = getattr(result, "structuredContent", None)
    if isinstance(structured, dict):
        if set(structured) == {"result"}:  # FastMCP non-dict returns ko wrap karta hai
            return structured["result"]
        return structured

    parsed = []
    for t in texts:
        try:
            parsed.append(json.loads(t))
        except json.JSONDecodeError:
            parsed.append(t)
    if not parsed:
        return None
    return parsed[0] if len(parsed) == 1 else parsed


class MCPManager:
    def __init__(self, servers: dict[str, list[str]] | None = None, timeout: int | None = None):
        self.servers = servers or DEFAULT_SERVERS
        self.timeout = timeout or config.MCP_CALL_TIMEOUT
        self.sessions: dict[str, Any] = {}
        self.tool_to_server: dict[str, str] = {}
        self.tool_specs: dict[str, dict] = {}
        self._stack = AsyncExitStack()

    async def connect(self) -> None:
        from mcp import ClientSession, StdioServerParameters  # lazy import
        from mcp.client.stdio import stdio_client

        for name, args in self.servers.items():
            env = dict(os.environ)
            env["PYTHONPATH"] = str(config.ROOT) + os.pathsep + env.get("PYTHONPATH", "")
            params = StdioServerParameters(command=sys.executable, args=args, env=env, cwd=str(config.ROOT))
            read, write = await self._stack.enter_async_context(stdio_client(params))
            session = await self._stack.enter_async_context(ClientSession(read, write))
            await session.initialize()
            self.sessions[name] = session

            listed = await session.list_tools()  # tool discovery
            for t in listed.tools:
                if t.name in self.tool_to_server:
                    raise RuntimeError(f"Duplicate tool name across servers: {t.name}")
                self.tool_to_server[t.name] = name
                self.tool_specs[t.name] = {
                    "name": t.name,
                    "description": t.description or "",
                    "inputSchema": t.inputSchema or {},
                }
            log.info("Connected to MCP server '%s' (%d tools)", name, len(listed.tools))

    async def call_tool(self, name: str, args: dict | None = None, timeout: int | None = None) -> Any:
        args = args or {}
        server = self.tool_to_server.get(name)
        if server is None:
            raise ToolError(f"Unknown tool: {name}")
        start = time.perf_counter()
        try:
            result = await asyncio.wait_for(
                self.sessions[server].call_tool(name, args), timeout=timeout or self.timeout
            )
            parsed = parse_tool_result(result)
        except asyncio.TimeoutError:
            log_tool_call(name, args, "error", (time.perf_counter() - start) * 1000, "mcp_client", "timeout")
            raise ToolError(f"Tool '{name}' timed out") from None
        except Exception as exc:  # noqa: BLE001
            log_tool_call(name, args, "error", (time.perf_counter() - start) * 1000, "mcp_client", str(exc))
            raise ToolError(str(exc)) from exc
        size = len(json.dumps(parsed, default=str))
        log_tool_call(name, args, "ok", (time.perf_counter() - start) * 1000, "mcp_client", result_chars=size)
        return parsed

    async def close(self) -> None:
        await self._stack.aclose()


class SyncMCPClient:
    """MCPManager ko apne event-loop thread mein chalata hai; baqi code sync call() use kare."""

    def __init__(self, servers: dict[str, list[str]] | None = None):
        self._servers = servers
        self._thread: threading.Thread | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._stop: asyncio.Event | None = None
        self._mgr: MCPManager | None = None
        self._ready = threading.Event()
        self._error: BaseException | None = None

    @property
    def tool_specs(self) -> dict[str, dict]:
        return self._mgr.tool_specs if self._mgr else {}

    def start(self, timeout: float = 60) -> None:
        self._thread = threading.Thread(target=lambda: asyncio.run(self._main()), daemon=True)
        self._thread.start()
        if not self._ready.wait(timeout):
            raise TimeoutError("MCP servers did not start in time")
        if self._error:
            raise RuntimeError(f"MCP startup failed: {self._error}") from self._error

    async def _main(self) -> None:
        self._loop = asyncio.get_running_loop()
        self._stop = asyncio.Event()
        mgr = MCPManager(self._servers)
        try:
            await mgr.connect()
            self._mgr = mgr
        except BaseException as exc:  # noqa: BLE001
            self._error = exc
            self._ready.set()
            try:
                await mgr.close()
            except BaseException:  # noqa: BLE001
                pass
            return
        self._ready.set()
        try:
            await self._stop.wait()
        finally:
            await mgr.close()

    def call(self, name: str, args: dict | None = None, timeout: int | None = None) -> Any:
        if not self._mgr or not self._loop:
            raise RuntimeError("MCP client not started")
        fut = asyncio.run_coroutine_threadsafe(self._mgr.call_tool(name, args, timeout), self._loop)
        return fut.result((timeout or config.MCP_CALL_TIMEOUT) + 5)

    def stop(self) -> None:
        if self._loop and self._stop:
            self._loop.call_soon_threadsafe(self._stop.set)
        if self._thread:
            self._thread.join(timeout=10)
