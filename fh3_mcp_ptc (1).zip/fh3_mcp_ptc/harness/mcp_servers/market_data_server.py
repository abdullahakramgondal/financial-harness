"""MCP server #1: market data (Step 2).

Run (alag se test karne ke liye):  python -m harness.mcp_servers.market_data_server
Inspector:                          mcp dev harness/mcp_servers/market_data_server.py
"""
from mcp.server.fastmcp import FastMCP

from .. import data_provider as dp

mcp = FastMCP("nasdaq-market-data")


@mcp.tool()
def get_quote(symbol: str) -> dict:
    """Latest quote (price, previous close, change) for a Nasdaq-listed symbol."""
    return dp.get_quote(symbol)


@mcp.tool()
def get_history(symbol: str, days: int = 90) -> dict:
    """Daily OHLCV bars for the last N trading days (5-500). Oldest first."""
    return dp.get_history(symbol, days)


@mcp.tool()
def list_symbols() -> dict:
    """List the symbols available in this harness with their sectors."""
    return dp.list_symbols()


if __name__ == "__main__":
    mcp.run()  # stdio transport
