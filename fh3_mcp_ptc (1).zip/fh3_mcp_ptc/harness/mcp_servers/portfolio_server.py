"""MCP server #2: portfolio (Step 3).

Run:  python -m harness.mcp_servers.portfolio_server
Holdings data/holdings.json se aati hain (database baad ka kaam hai).
"""
from mcp.server.fastmcp import FastMCP

from .. import portfolio_logic as pl

mcp = FastMCP("portfolio")


@mcp.tool()
def get_positions() -> dict:
    """Current holdings with live price, market value and P&L."""
    return pl.get_positions()


@mcp.tool()
def calc_exposure() -> dict:
    """Portfolio weights by sector and by symbol (percent of total market value)."""
    return pl.calc_exposure()


@mcp.tool()
def calc_risk(days: int = 90) -> dict:
    """Risk metrics for the current holdings over the last N days: annualised volatility,
    beta vs QQQ, max drawdown and 1-day 95% historical VaR."""
    return pl.calc_risk(days)


if __name__ == "__main__":
    mcp.run()  # stdio transport
