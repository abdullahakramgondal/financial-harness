"""Portfolio calculations (Step 3). Pure Python, MCP se independent hai (test karna aasan)."""
from __future__ import annotations

import json
import math
import statistics
from typing import Any

from . import config, data_provider as dp


def _load_holdings() -> list[dict]:
    with open(config.HOLDINGS_FILE, encoding="utf-8") as f:
        return json.load(f)


def get_positions() -> dict:
    """Current holdings with live price, market value and P&L."""
    positions, total_value, total_cost, sources = [], 0.0, 0.0, set()
    for h in _load_holdings():
        q = dp.get_quote(h["symbol"])
        sources.add(q["source"])
        value = h["shares"] * q["price"]
        cost = h["shares"] * h["avg_cost"]
        total_value += value
        total_cost += cost
        positions.append(
            {
                "symbol": h["symbol"],
                "sector": dp.UNIVERSE.get(h["symbol"], "Other"),
                "shares": h["shares"],
                "avg_cost": h["avg_cost"],
                "price": q["price"],
                "market_value": round(value, 2),
                "pnl": round(value - cost, 2),
                "pnl_pct": round((value / cost - 1) * 100, 2) if cost else 0.0,
            }
        )
    return {
        "positions": positions,
        "total_value": round(total_value, 2),
        "total_cost": round(total_cost, 2),
        "total_pnl": round(total_value - total_cost, 2),
        "total_pnl_pct": round((total_value / total_cost - 1) * 100, 2) if total_cost else 0.0,
        "sources": sorted(sources),
    }


def calc_exposure() -> dict:
    """Portfolio weights by sector and by symbol (percent of total market value)."""
    pos = get_positions()
    total = pos["total_value"] or 1.0
    by_sector: dict[str, float] = {}
    for p in pos["positions"]:
        by_sector[p["sector"]] = by_sector.get(p["sector"], 0.0) + p["market_value"]
    sectors = sorted(
        ({"sector": s, "value": round(v, 2), "weight_pct": round(v / total * 100, 2)} for s, v in by_sector.items()),
        key=lambda x: x["weight_pct"],
        reverse=True,
    )
    symbols = sorted(
        (
            {"symbol": p["symbol"], "weight_pct": round(p["market_value"] / total * 100, 2)}
            for p in pos["positions"]
        ),
        key=lambda x: x["weight_pct"],
        reverse=True,
    )
    return {
        "total_value": pos["total_value"],
        "by_sector": sectors,
        "by_symbol": symbols,
        "top_holding": symbols[0] if symbols else None,
    }


def _closes(symbol: str, n: int) -> tuple[dict[str, float], str]:
    h = dp.get_history(symbol, n)
    return {b["date"]: b["close"] for b in h["bars"]}, h["source"]


def calc_risk(days: int = 90) -> dict:
    """Risk metrics for the current holdings over the last N days: annualised volatility,
    beta vs QQQ, max drawdown and 1-day 95% historical VaR (hypothetical: constant shares)."""
    days = max(10, min(int(days), 500))
    holdings = _load_holdings()
    series, sources = {}, set()
    for h in holdings:
        series[h["symbol"]], src = _closes(h["symbol"], days + 1)
        sources.add(src)
    bench, src = _closes("QQQ", days + 1)
    sources.add(src)

    dates = sorted(set.intersection(*[set(s) for s in series.values()], set(bench)))
    if len(dates) < 5:
        raise RuntimeError("Not enough overlapping history to compute risk")

    values = [sum(h["shares"] * series[h["symbol"]][d] for h in holdings) for d in dates]
    p_ret = [values[i] / values[i - 1] - 1 for i in range(1, len(values))]
    b_ret = [bench[dates[i]] / bench[dates[i - 1]] - 1 for i in range(1, len(dates))]

    vol = statistics.stdev(p_ret) * math.sqrt(252)
    mp, mb = statistics.fmean(p_ret), statistics.fmean(b_ret)
    cov = sum((a - mp) * (b - mb) for a, b in zip(p_ret, b_ret)) / (len(p_ret) - 1)
    var_b = statistics.variance(b_ret)
    beta = cov / var_b if var_b else float("nan")

    peak, mdd = values[0], 0.0
    for v in values:
        peak = max(peak, v)
        mdd = min(mdd, v / peak - 1)
    var95 = -sorted(p_ret)[max(0, int(0.05 * len(p_ret)) - 1)]

    return {
        "days": len(p_ret),
        "annual_volatility_pct": round(vol * 100, 2),
        "beta_vs_qqq": round(beta, 2),
        "max_drawdown_pct": round(mdd * 100, 2),
        "var_95_1d_pct": round(var95 * 100, 2),
        "sources": sorted(sources),
    }
