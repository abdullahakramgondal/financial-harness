"""PTC bridge (Step 5) - sab se important hissa.

Idea:
   agent ka likha Python code (sandbox ke andar)  --HTTP-->  Bridge (harness side)
        tools.get_history("AAPL")                              allow-list check
                                                               approval check (FH-4 hook)
                                                               call limit
                                                               MCP client -> asli tool
   result sirf us code ko milta hai; context window mein sirf code ka print() output jata hai.

Security:
  * sirf 127.0.0.1 par sunta hai, har run ka random token hota hai
  * ALLOWED_TOOLS ke bahar kuch nahi chalta
  * RESTRICTED_TOOLS (trade jaise) default mein block; FH-4 approval_hook de to hi chalen
"""
from __future__ import annotations

import json
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable

from . import config
from .logger import get_logger, log_tool_call

log = get_logger(__name__)

ALLOWED_TOOLS = {"get_quote", "get_history", "list_symbols", "get_positions", "calc_exposure", "calc_risk"}
RESTRICTED_TOOLS = {"place_order", "cancel_order", "execute_rebalance"}  # FH-4 approval flow ka kaam


class PTCBridge:
    def __init__(
        self,
        client: Any,
        allowed: set[str] | None = None,
        restricted: set[str] | None = None,
        max_calls: int | None = None,
        approval_hook: Callable[[str, dict], bool] | None = None,
    ):
        self.client = client
        self.allowed = set(allowed if allowed is not None else ALLOWED_TOOLS)
        self.restricted = set(restricted if restricted is not None else RESTRICTED_TOOLS)
        self.max_calls = max_calls or config.MAX_BRIDGE_CALLS
        self.approval_hook = approval_hook
        self.token = secrets.token_hex(16)
        self.stats = {"calls": 0, "denied": 0, "raw_chars": 0}
        self._lock = threading.Lock()
        self._server: ThreadingHTTPServer | None = None

    # ---------------------------------------------------------- lifecycle
    def start(self) -> None:
        bridge = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *a: Any) -> None:  # console shor nahi
                pass

            def _send(self, code: int, body: dict) -> None:
                data = json.dumps(body, default=str).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def do_POST(self) -> None:  # noqa: N802
                if self.path != "/call":
                    return self._send(404, {"ok": False, "error": "not found"})
                if self.headers.get("X-Bridge-Token") != bridge.token:
                    return self._send(401, {"ok": False, "error": "bad token"})
                try:
                    length = int(self.headers.get("Content-Length", 0))
                    req = json.loads(self.rfile.read(length) or b"{}")
                    result = bridge.handle_call(req["tool"], req.get("args") or {})
                    self._send(200, {"ok": True, "result": result})
                except PermissionError as exc:
                    self._send(403, {"ok": False, "error": str(exc)})
                except Exception as exc:  # noqa: BLE001
                    self._send(500, {"ok": False, "error": f"{type(exc).__name__}: {exc}"})

        self._server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        threading.Thread(target=self._server.serve_forever, daemon=True).start()
        log.info("PTC bridge listening on %s", self.url)

    def stop(self) -> None:
        if self._server:
            self._server.shutdown()
            self._server.server_close()

    @property
    def url(self) -> str:
        assert self._server, "bridge not started"
        return f"http://127.0.0.1:{self._server.server_address[1]}"

    # ---------------------------------------------------------- core logic
    def handle_call(self, tool: str, args: dict) -> Any:
        start = time.perf_counter()
        if tool in self.restricted:
            approved = bool(self.approval_hook and self.approval_hook(tool, args))
            if not approved:
                self._deny(tool, args, start, "requires approval")
                raise PermissionError(f"'{tool}' requires human approval (FH-4) and is blocked")
        elif tool not in self.allowed:
            self._deny(tool, args, start, "not in allow-list")
            raise PermissionError(f"'{tool}' is not in the allow-list")

        with self._lock:
            self.stats["calls"] += 1
            over_limit = self.stats["calls"] > self.max_calls
        if over_limit:  # lock ke bahar deny karein (Lock re-entrant nahi hota)
            self._deny(tool, args, start, "call limit")
            raise PermissionError(f"Tool call limit ({self.max_calls}) exceeded")

        result = self.client.call(tool, args)
        with self._lock:
            self.stats["raw_chars"] += len(json.dumps(result, default=str))
        return result

    def _deny(self, tool: str, args: dict, start: float, reason: str) -> None:
        with self._lock:
            self.stats["denied"] += 1
        log_tool_call(tool, args, "denied", (time.perf_counter() - start) * 1000, "ptc_bridge", reason)

    # ---------------------------------------------------------- stub generation
    def _exposed_specs(self) -> list[dict]:
        specs = getattr(self.client, "tool_specs", {})
        return [specs[n] for n in sorted(self.allowed) if n in specs]

    def tool_docs(self) -> list[str]:
        """Agent/LLM ko dikhane ke liye short signatures."""
        out = []
        for spec in self._exposed_specs():
            params = _params(spec)
            sig = ", ".join(p if d is _REQ else f"{p}={d!r}" for p, d in params)
            out.append(f"tools.{spec['name']}({sig}) -> dict  # {spec['description']}")
        return out

    def stub_source(self) -> str:
        """Sandbox ke andar jane wala tools.py: har allowed MCP tool ek Python function banta hai."""
        lines = [_STUB_HEADER]
        for spec in self._exposed_specs():
            params = _params(spec)
            sig = ", ".join(p if d is _REQ else f"{p}={d!r}" for p, d in params)
            payload = ", ".join(f"{p!r}: {p}" for p, _ in params)
            lines.append(
                f"def {spec['name']}({sig}):\n"
                f"    return _call({spec['name']!r}, {{{payload}}})\n"
                f"{spec['name']}.__doc__ = {spec['description']!r}\n"
            )
        return "\n".join(lines)


_REQ = object()


def _params(spec: dict) -> list[tuple[str, Any]]:
    schema = spec.get("inputSchema") or {}
    props, required = schema.get("properties", {}), set(schema.get("required", []))
    req = [(p, _REQ) for p in props if p in required]
    opt = [(p, props[p].get("default")) for p in props if p not in required]
    return req + opt


_STUB_HEADER = '''"""Auto-generated PTC stub. Har function harness bridge ko HTTP call bhejta hai."""
import json
import os
import urllib.error
import urllib.request

_URL = os.environ["BRIDGE_URL"]
_TOKEN = os.environ["BRIDGE_TOKEN"]
_opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))


class ToolCallError(Exception):
    pass


def _call(tool, args):
    data = json.dumps({"tool": tool, "args": args}).encode()
    req = urllib.request.Request(
        _URL + "/call", data=data,
        headers={"Content-Type": "application/json", "X-Bridge-Token": _TOKEN},
    )
    try:
        body = json.loads(_opener.open(req, timeout=60).read())
    except urllib.error.HTTPError as e:
        try:
            body = json.loads(e.read() or b"{}")
        except ValueError:
            body = {}
        raise ToolCallError(body.get("error", "HTTP %s" % e.code))
    if not body.get("ok"):
        raise ToolCallError(body.get("error", "unknown error"))
    return body["result"]

'''
