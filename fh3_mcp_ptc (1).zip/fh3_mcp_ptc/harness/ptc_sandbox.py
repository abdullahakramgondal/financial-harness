"""Minimal code runner for PTC (Step 5).

Ye FH-5 (Aima ka real sandbox) ka *placeholder* hai: agent ka code ek temp folder mein
alag subprocess mein chalta hai (timeout, saaf environment, output limit).
IMPORTANT: ye asli isolation nahi hai (Docker/gVisor jaisi). Untrusted code ke liye FH-5
ka sandbox use hona chahiye; sirf `run_code(code, bridge)` ka interface same rahega.
"""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from . import config
from .ptc_bridge import PTCBridge


def _clip(text: str, limit: int) -> str:
    return text if len(text) <= limit else text[:limit] + f"\n...[clipped {len(text) - limit} chars]"


def run_code(code: str, bridge: PTCBridge, timeout: int | None = None, max_output: int = 20000) -> dict:
    timeout = timeout or config.SANDBOX_TIMEOUT
    calls_before = bridge.stats["calls"]
    start = time.perf_counter()
    with tempfile.TemporaryDirectory(prefix="ptc_") as d:
        work = Path(d)
        (work / "tools.py").write_text(bridge.stub_source(), encoding="utf-8")
        (work / "agent_code.py").write_text(code, encoding="utf-8")

        env = {
            "PATH": os.environ.get("PATH", ""),
            "BRIDGE_URL": bridge.url,
            "BRIDGE_TOKEN": bridge.token,
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONIOENCODING": "utf-8",
        }
        for k in ("SYSTEMROOT", "TEMP", "TMP"):  # Windows par zaroori
            if k in os.environ:
                env[k] = os.environ[k]

        try:
            p = subprocess.run(
                [sys.executable, "agent_code.py"],
                cwd=d, env=env, capture_output=True, text=True, encoding="utf-8", timeout=timeout,
            )
            stdout, stderr, rc = p.stdout, p.stderr, p.returncode
        except subprocess.TimeoutExpired:
            stdout, stderr, rc = "", f"Timed out after {timeout}s", -1

    return {
        "ok": rc == 0,
        "returncode": rc,
        "stdout": _clip(stdout, max_output),
        "stderr": _clip(stderr, max_output),
        "duration_ms": round((time.perf_counter() - start) * 1000, 1),
        "tool_calls": bridge.stats["calls"] - calls_before,
    }
