"""FH-3 end-to-end demo: MCP + PTC + context management.

    python run_demo.py            # asli MCP servers (stdio) ke saath
    python run_demo.py --local    # MCP ke baghair (fallback; logic wahi)
    python run_demo.py --llm      # agent code Claude likhe (ANTHROPIC_API_KEY chahiye)
    python run_demo.py --code-file my_agent.py
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime

from harness import config
from harness.agent_demo import DEFAULT_AGENT_CODE, DEMO_QUESTION
from harness.context_adapter import ContextAdapter
from harness.ptc_bridge import PTCBridge
from harness.ptc_sandbox import run_code


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--local", action="store_true", help="MCP ke baghair, functions seedha call")
    ap.add_argument("--llm", action="store_true", help="agent code Claude se generate karwao")
    ap.add_argument("--question", default=DEMO_QUESTION)
    ap.add_argument("--code-file", help="apni Python file chalao (import tools use karti ho)")
    args = ap.parse_args()

    if args.local:
        from harness.local_client import LocalClient

        client = LocalClient()
    else:
        from harness.mcp_client import SyncMCPClient

        client = SyncMCPClient()

    try:
        client.start()
    except Exception as exc:  # noqa: BLE001
        print(f"\n[!] MCP start nahi hua: {exc}\n    Hint: `pip install -r requirements.txt` ya `--local` try karein.")
        return 2

    bridge = PTCBridge(client)
    bridge.start()
    try:
        print(f"Mode        : {'LOCAL (no MCP)' if args.local else 'MCP (stdio) + PTC'}")
        print(f"Data source : {config.DATA_PROVIDER}")
        print(f"MCP tools   : {', '.join(sorted(client.tool_specs))}")
        print(f"Question    : {args.question}\n")

        if args.code_file:
            code = open(args.code_file, encoding="utf-8").read()
        elif args.llm:
            from harness.llm_agent import generate_code

            code = generate_code(args.question, bridge.tool_docs())
            print("--- LLM generated code ---\n" + code + "\n--------------------------\n")
        else:
            code = DEFAULT_AGENT_CODE

        result = run_code(code, bridge)
    finally:
        bridge.stop()
        client.stop()

    # Step 6: sirf sandbox ka output context mein jata hai
    adapter = ContextAdapter()
    ctx = adapter.process("sandbox_stdout" if result["ok"] else "sandbox_stderr",
                          result["stdout"] if result["ok"] else result["stderr"])

    print("=== Result jo agent ke CONTEXT mein jata hai ===")
    print(ctx.get("content") or ctx["summary"])
    if ctx["truncated"]:
        print(f"(bada output: file mein save -> {ctx['artifact_path']})")
    print("\n=== Stats ===")
    print(f"Sandbox ok          : {result['ok']} (rc={result['returncode']}, {result['duration_ms']} ms)")
    print(f"MCP tool calls      : {result['tool_calls']}  (denied: {bridge.stats['denied']})")
    print(f"Raw data via bridge : {bridge.stats['raw_chars']:,} chars  <- context mein NAHI gaya")
    print(f"Context mein gaya   : {ctx['chars']:,} chars (~{ctx['approx_tokens']} tokens)")
    if bridge.stats["raw_chars"]:
        print(f"Context bachat      : ~{(1 - ctx['chars'] / bridge.stats['raw_chars']) * 100:.0f}%")
    print(f"Tool-call log       : {config.LOG_DIR / 'tool_calls.jsonl'}")

    out = config.OUTPUT_DIR / "demo_result.json"
    out.write_text(
        json.dumps(
            {"ts": datetime.now().isoformat(), "question": args.question, "mode": "local" if args.local else "mcp",
             "provider": config.DATA_PROVIDER, "sandbox": result, "context": ctx, "bridge_stats": bridge.stats},
            indent=2, default=str),
        encoding="utf-8",
    )
    if not result["ok"]:
        print("\n[!] Sandbox error:\n" + result["stderr"])
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
