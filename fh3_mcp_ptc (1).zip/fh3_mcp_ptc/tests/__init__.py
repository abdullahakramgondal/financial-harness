import os

# Tests hamesha mock data par chalen (internet/API key ki zaroorat nahi)
os.environ["DATA_PROVIDER"] = "mock"
