import tempfile
import unittest
from pathlib import Path

from harness.context_adapter import ContextAdapter


class ContextAdapterTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.adapter = ContextAdapter(max_chars=200, artifact_dir=Path(self.tmp.name))

    def tearDown(self):
        self.tmp.cleanup()

    def test_small_payload_passes_through(self):
        out = self.adapter.process("x", {"a": 1})
        self.assertFalse(out["truncated"])
        self.assertIn('"a": 1', out["content"])

    def test_large_list_saved_to_file(self):
        payload = [{"i": i, "v": "x" * 20} for i in range(100)]
        out = self.adapter.process("big", payload)
        self.assertTrue(out["truncated"])
        self.assertIn("100 items", out["summary"])
        self.assertTrue(Path(out["artifact_path"]).exists())
        self.assertLess(len(out["summary"]), 400)

    def test_large_dict_summary(self):
        out = self.adapter.process("hist", {"symbol": "AAPL", "bars": [{"c": i} for i in range(200)]})
        self.assertIn("bars: list[200]", out["summary"])

    def test_read_artifact_and_path_guard(self):
        out = self.adapter.process("big", "y" * 1000)
        self.assertEqual(self.adapter.read_artifact(out["artifact_path"], 0, 10), "y" * 10)
        with self.assertRaises(PermissionError):
            self.adapter.read_artifact(__file__)


if __name__ == "__main__":
    unittest.main()
