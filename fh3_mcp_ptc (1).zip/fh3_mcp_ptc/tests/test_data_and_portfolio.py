import unittest

from harness import data_provider as dp, portfolio_logic as pl


class DataProviderTests(unittest.TestCase):
    def test_history_length_and_order(self):
        h = dp.get_history("AAPL", 30)
        self.assertEqual(h["count"], 30)
        self.assertEqual(h["source"], "mock")
        dates = [b["date"] for b in h["bars"]]
        self.assertEqual(dates, sorted(dates))

    def test_deterministic(self):
        self.assertEqual(dp.get_history("MSFT", 20)["bars"], dp.get_history("MSFT", 20)["bars"])

    def test_history_is_consistent_across_windows(self):
        a = dp.get_history("NVDA", 10)["bars"]
        b = dp.get_history("NVDA", 50)["bars"]
        self.assertEqual(a, b[-10:])

    def test_quote(self):
        q = dp.get_quote("aapl")
        self.assertEqual(q["symbol"], "AAPL")
        self.assertGreater(q["price"], 0)

    def test_invalid_symbol(self):
        with self.assertRaises(ValueError):
            dp.get_quote("DROP TABLE")


class PortfolioTests(unittest.TestCase):
    def test_positions(self):
        p = pl.get_positions()
        self.assertEqual(len(p["positions"]), 6)
        self.assertAlmostEqual(sum(x["market_value"] for x in p["positions"]), p["total_value"], places=1)

    def test_exposure_sums_to_100(self):
        e = pl.calc_exposure()
        self.assertAlmostEqual(sum(s["weight_pct"] for s in e["by_sector"]), 100.0, delta=0.1)

    def test_risk_fields(self):
        r = pl.calc_risk(60)
        self.assertGreater(r["annual_volatility_pct"], 0)
        self.assertLessEqual(r["max_drawdown_pct"], 0)
        self.assertIn("beta_vs_qqq", r)


if __name__ == "__main__":
    unittest.main()
