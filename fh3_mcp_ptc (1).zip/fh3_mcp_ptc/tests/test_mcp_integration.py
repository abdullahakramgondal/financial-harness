"""Asli MCP servers (stdio) ke saath test. `mcp` package install ho to hi chalta hai."""
import importlib.util
import unittest

HAS_MCP = importlib.util.find_spec("mcp") is not None


@unittest.skipUnless(HAS_MCP, "mcp package installed nahi (pip install -r requirements.txt)")
class MCPIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from harness.mcp_client import SyncMCPClient

        cls.client = SyncMCPClient()
        cls.client.start()

    @classmethod
    def tearDownClass(cls):
        cls.client.stop()

    def test_tool_discovery(self):
        names = set(self.client.tool_specs)
        self.assertTrue({"get_quote", "get_history", "list_symbols", "get_positions", "calc_exposure", "calc_risk"} <= names)

    def test_call_quote(self):
        q = self.client.call("get_quote", {"symbol": "AAPL"})
        self.assertEqual(q["symbol"], "AAPL")

    def test_call_history_shape(self):
        h = self.client.call("get_history", {"symbol": "AAPL", "days": 20})
        self.assertEqual(len(h["bars"]), 20)

    def test_portfolio_tools(self):
        self.assertIn("by_sector", self.client.call("calc_exposure", {}))
        self.assertIn("beta_vs_qqq", self.client.call("calc_risk", {"days": 60}))

    def test_error_is_raised(self):
        from harness.mcp_client import ToolError

        with self.assertRaises(ToolError):
            self.client.call("get_quote", {"symbol": "!!bad!!"})

    def test_end_to_end_ptc_over_mcp(self):
        from harness.ptc_bridge import PTCBridge
        from harness.ptc_sandbox import run_code

        bridge = PTCBridge(self.client)
        bridge.start()
        try:
            r = run_code("import tools\nprint(tools.get_quote('MSFT')['symbol'])", bridge)
            self.assertTrue(r["ok"], r["stderr"])
            self.assertEqual(r["stdout"].strip(), "MSFT")
        finally:
            bridge.stop()


if __name__ == "__main__":
    unittest.main()
