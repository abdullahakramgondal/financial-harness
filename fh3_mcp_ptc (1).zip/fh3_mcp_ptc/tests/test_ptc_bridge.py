import unittest

from harness.local_client import LocalClient
from harness.ptc_bridge import PTCBridge
from harness.ptc_sandbox import run_code


class PTCBridgeTests(unittest.TestCase):
    def setUp(self):
        self.client = LocalClient()
        self.bridge = PTCBridge(self.client)
        self.bridge.start()

    def tearDown(self):
        self.bridge.stop()

    def test_stub_exposes_only_allowed_tools(self):
        src = self.bridge.stub_source()
        self.assertIn("def get_history(symbol, days=90)", src)
        self.assertNotIn("place_order", src)

    def test_ptc_call_works(self):
        r = run_code("import tools\nq = tools.get_quote('AAPL')\nprint(q['symbol'])", self.bridge)
        self.assertTrue(r["ok"], r["stderr"])
        self.assertEqual(r["stdout"].strip(), "AAPL")
        self.assertEqual(r["tool_calls"], 1)

    def test_raw_data_stays_out_of_output(self):
        code = "import tools\nh = tools.get_history('AAPL', 200)\nprint(len(h['bars']))"
        r = run_code(code, self.bridge)
        self.assertTrue(r["ok"], r["stderr"])
        self.assertEqual(r["stdout"].strip(), "200")
        self.assertGreater(self.bridge.stats["raw_chars"], 10 * len(r["stdout"]))

    def test_allowlist_blocks_unknown_tool(self):
        code = (
            "import tools\n"
            "try:\n    tools._call('delete_everything', {})\n"
            "except tools.ToolCallError as e:\n    print('blocked:', e)\n"
        )
        r = run_code(code, self.bridge)
        self.assertIn("blocked:", r["stdout"])
        self.assertEqual(self.bridge.stats["denied"], 1)

    def test_trade_tool_requires_approval(self):
        code = (
            "import tools\n"
            "try:\n    tools._call('place_order', {'symbol': 'AAPL'})\n"
            "except tools.ToolCallError as e:\n    print('blocked:', e)\n"
        )
        r = run_code(code, self.bridge)
        self.assertIn("approval", r["stdout"])

    def test_restricted_tool_blocked_without_hook(self):
        self.assertTrue(self.bridge.approval_hook is None)
        with self.assertRaises(PermissionError):
            self.bridge.handle_call("place_order", {})

    def test_invalid_args_become_tool_error(self):
        code = (
            "import tools\n"
            "try:\n    tools.get_quote('!!bad!!')\n"
            "except tools.ToolCallError as e:\n    print('error:', e)\n"
        )
        r = run_code(code, self.bridge)
        self.assertIn("error:", r["stdout"])

    def test_call_limit(self):
        bridge = PTCBridge(self.client, max_calls=2)
        bridge.start()
        try:
            code = (
                "import tools\n"
                "try:\n    [tools.get_quote('AAPL') for _ in range(5)]\n"
                "except tools.ToolCallError as e:\n    print('limit:', e)\n"
            )
            r = run_code(code, bridge)
            self.assertIn("limit:", r["stdout"])
        finally:
            bridge.stop()

    def test_timeout(self):
        r = run_code("import time\ntime.sleep(5)", self.bridge, timeout=1)
        self.assertFalse(r["ok"])
        self.assertIn("Timed out", r["stderr"])

    def test_bad_token_rejected(self):
        import json, urllib.request, urllib.error
        req = urllib.request.Request(self.bridge.url + "/call", data=json.dumps({"tool": "list_symbols"}).encode(),
                                     headers={"X-Bridge-Token": "wrong"})
        with self.assertRaises(urllib.error.HTTPError) as cm:
            urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req)
        self.assertEqual(cm.exception.code, 401)


if __name__ == "__main__":
    unittest.main()
